package com.razmgir.rahim.fourthian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    TextView questiontxt;
    EditText answertxt;
    int question, level, questionNum;
    double startTime;
    ProgressBar p;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        questiontxt = findViewById(R.id.textView4);
        answertxt = findViewById(R.id.editText);
        question = (int)(Math.random() * 14) + 2;
        questiontxt.setText(String.valueOf(question * question));
        p = findViewById(R.id.progressBar);

        startTime = System.currentTimeMillis();
    }

    public void contact(View v){
        Intent i = new Intent(getApplicationContext(), Main3Activity.class);
        startActivity(i);
    }

    public void check(View v){
        questionNum ++;
        String uanswer = String.valueOf(answertxt.getText());
        if (uanswer.length() == 0){
            uanswer = "0";
        }
        int answer = Integer.parseInt(uanswer);
        if (answer == question){
            Toast.makeText(this, "Correct", Toast.LENGTH_SHORT).show();
            level += 10;
            p.setProgress(level);
        } else {
            Toast.makeText(this,"Wrong", Toast.LENGTH_SHORT).show();
            level -= 5;
            p.setProgress(level);
        }
        question = (int)(Math.random() * 14) + 2;
        questiontxt.setText(String.valueOf(question * question));
        answertxt.setText("");
        answertxt.requestFocus();

        if (level >= 100){
            double difference = System.currentTimeMillis() - startTime;
            Intent i = new Intent(getApplicationContext(), Main4Activity.class);
            i.putExtra("total", questionNum);
            i .putExtra("time", difference/1000);
            startActivity(i);
        }
    }
}
