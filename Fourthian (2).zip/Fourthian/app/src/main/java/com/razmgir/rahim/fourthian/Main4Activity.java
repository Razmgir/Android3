package com.razmgir.rahim.fourthian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main4Activity extends AppCompatActivity {
    TextView totalQuestions, totalTime, avgTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        totalQuestions = findViewById(R.id.textQuestions);
        totalTime = findViewById(R.id.textTime);
        avgTime = findViewById(R.id.textAvg);

        int total = getIntent().getExtras().getInt("total");
        totalQuestions.setText("Number of Questions: " + total);

        double time = getIntent().getExtras().getDouble("time");
        totalTime.setText("Time Spent: " + time + " s");

        double average = time/total;
        String result = String.format("%.2f", average);
        avgTime.setText("Average: " + result + " s/q");
    }

    public void contact(View v){
        Intent i = new Intent(getApplicationContext(), Main3Activity.class);
        startActivity(i);
    }
}
