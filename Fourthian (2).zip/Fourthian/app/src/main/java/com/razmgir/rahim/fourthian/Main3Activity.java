package com.razmgir.rahim.fourthian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
    EditText name, email, message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        name = findViewById(R.id.editText2);
        email = findViewById(R.id.editText3);
        message = findViewById(R.id.editText4);
    }

    public void send (View v){
        String username = String.valueOf(name.getText());
        String useremail = String.valueOf(email.getText());
        String usermessage = String.valueOf(message.getText());
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("message/rfc822");
        i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"recipient@example.com"});
        i.putExtra(Intent.EXTRA_SUBJECT, "Email from " + username);
        i.putExtra(Intent.EXTRA_TEXT   , Html.fromHtml(new StringBuilder()
                .append("<p><strong>Some Content</strong></p>")
                .append(username)
                .append("<h1 style='color: red;'>More content</h1>")
                .toString()));
        try {
            startActivity(Intent.createChooser(i, "Send mail..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
        }
    }















    public void call (View v){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:6478719700"));
        startActivity(intent);
    }
}
