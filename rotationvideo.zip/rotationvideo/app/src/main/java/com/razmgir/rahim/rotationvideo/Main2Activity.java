package com.razmgir.rahim.rotationvideo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Main2Activity extends AppCompatActivity {

    ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        image = findViewById(R.id.imageView);

        Animation myAnim;

        myAnim = AnimationUtils.loadAnimation(this, R.anim.scale);
        myAnim.reset();
        image.clearAnimation();
        image.startAnimation(myAnim);

        final Intent i = new Intent(getApplicationContext(), Main3Activity.class);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                startActivity(i);
            }
        }, 4000);

    }
}
