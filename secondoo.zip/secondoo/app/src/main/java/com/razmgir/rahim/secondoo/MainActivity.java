package com.razmgir.rahim.secondoo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView number;
    int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number = findViewById(R.id.txt);
    }

    public void hello (View v){
        Toast.makeText(this, "Heyyy buddy!", Toast.LENGTH_SHORT).show();
    }

    public void add (View v){
        num++;
        printResult();
    }

    public void subtract (View v){
        if (num > 0) {
            num--;
        }
        printResult();
    }

    public void odd (View v){
//         num++; //add 1
//         if (num%2 == 0) { //even?
//             num++; //add 1 again
//         }
        num = num * 2 + 1 - num + num%2;
        printResult();
    }

    public void prime (View v){
        boolean prime = false;
        while (prime == false) {
            num++;
            prime = true;
            for (int i = 2; i < num; i++){
                if (num % i == 0){
                    prime = false;
                    break;
                }
            }
        }
        printResult();
    }

    public void printResult(){
        if (num < 20) number.setTextColor(Color.GREEN);
        if (num >= 20)  number.setTextColor(Color.rgb(255,165,0));
        if (num > 50) number.setTextColor(Color.RED);
        number.setText(Integer.toString(num));
    }
}
