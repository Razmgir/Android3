package com.razmgir.rahim.sixmax;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.s);
    }



    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.main:
                Intent i1 = new Intent(this, Main2Activity.class);
                startActivity(i1);
                break;
            case R.id.website:
                Intent i2 = new Intent(this, Main3Activity.class);
                startActivity(i2);
                break;
            case R.id.video:
                Intent i3 =new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=yVzUj0oAYOk"));
                startActivity(i3);
                break;
            case R.id.stock:
                Intent i4 = new Intent(this, Main4Activity.class);
                startActivity(i4);
                break;
        }
        return true;
    }

}
