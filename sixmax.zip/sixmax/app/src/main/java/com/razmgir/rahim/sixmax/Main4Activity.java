package com.razmgir.rahim.sixmax;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class Main4Activity extends AppCompatActivity {
    EditText stock;
    WebView wv;
    String apiURL;
    URL u;
    TextView price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.s);

        stock = findViewById(R.id.editText);
        wv = findViewById(R.id.web);
        price = findViewById(R.id.textView5);
    }
    public void check (View v){
        String ticker = String.valueOf(stock.getText());
        //wv.loadUrl("https://cloud.iexapis.com/stable/stock/" + ticker + "/quote/latestPrice?token=pk_efe5532d5ed64427894506333955c667");
        apiURL = "https://cloud.iexapis.com/stable/stock/" + ticker + "/quote/latestPrice?token=pk_efe5532d5ed64427894506333955c667";
        new Thread() {
            @Override
            public void run() {
                try {
                    u = new URL(apiURL);
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("GET");
                    c.connect();
                    InputStream in = c.getInputStream();
                    final ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    in.read(buffer); // Read from Buffer.
                    bo.write(buffer); // Write Into Buffer.

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            price.setText("Current price: $"+ bo.toString());
                            try {
                                bo.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.main:
                Intent i1 = new Intent(this, Main2Activity.class);
                startActivity(i1);
                break;
            case R.id.website:
                Intent i2 = new Intent(this, Main3Activity.class);
                startActivity(i2);
                break;
            case R.id.video:
                Intent i3 =new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=yVzUj0oAYOk"));
                startActivity(i3);
                break;
            case R.id.stock:
                Intent i4 = new Intent(this, Main4Activity.class);
                startActivity(i4);
                break;
        }
        return true;
    }
}
