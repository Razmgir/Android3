package com.razmgir.rahim.firsty;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView text;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.btn);

        text = findViewById(R.id.txt);
    }

    public void change(View v) {
        if (text.getText()== "Hello world"){
            text.setText("Hello sexy!");
        } else {
            text.setText("Hello world");
        }

    }


}
