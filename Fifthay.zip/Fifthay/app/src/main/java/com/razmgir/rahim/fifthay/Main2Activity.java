package com.razmgir.rahim.fifthay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


import com.google.android.material.snackbar.Snackbar;

public class Main2Activity extends AppCompatActivity {
    TextView t1,t2,t3,t4,t5,t6,t7,t8,t9;
    String r1,r2,r3,r4,r5,r6,r7,r8,r9;
    ToggleButton t;
    boolean turn = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        t3 = findViewById(R.id.t3);
        t4 = findViewById(R.id.t4);
        t5 = findViewById(R.id.t5);
        t6 = findViewById(R.id.t6);
        t7 = findViewById(R.id.t7);
        t8 = findViewById(R.id.t8);
        t9 = findViewById(R.id.t9);
        t = findViewById(R.id.toggleButton);

    }

    public void s1(View v){
        t1.setText(play());
        check();
    }
    public void s2(View v){
        t2.setText(play());
        check();
    }
    public void s3(View v){
        t3.setText(play());
        check();
    }
    public void s4(View v){
        t4.setText(play());
        check();
    }
    public void s5(View v){
        t5.setText(play());
        check();
    }
    public void s6(View v){
        t6.setText(play());
        check();
    }
    public void s7(View v){
        t7.setText(play());
        check();
    }
    public void s8(View v){
        t8.setText(play());
        check();
    }
    public void s9(View v){
        t9.setText(play());
        check();
    }

    public String play(){
        String text = "";
        if (!t.isChecked()){
            if (turn == false){
                text = "O";
                turn = true;
            } else {
                text = "X";
                turn = false;
            }
        } else {
            if (turn == false){
                text = "X";
                turn = true;
            } else {
                text = "O";
                turn = false;
            }
        }
        return text;
    }
    public void check(){
        r1 = String.valueOf(t1.getText());
        r2 = String.valueOf(t2.getText());
        r3 = String.valueOf(t3.getText());
        r4 = String.valueOf(t4.getText());
        r5 = String.valueOf(t5.getText());
        r6 = String.valueOf(t6.getText());
        r7 = String.valueOf(t7.getText());
        r8 = String.valueOf(t8.getText());
        r9 = String.valueOf(t9.getText());
        if (r1 == r2 && r2 == r3){
            Toast.makeText(this, "Winner is " + r1, Toast.LENGTH_SHORT).show();
        }
        if (r4 == r5 && r5 == r6){
            Toast.makeText(this, "Winner is " + r4, Toast.LENGTH_SHORT).show();
        }
        if (r7 == r8 && r8 == r9){
            Toast.makeText(this, "Winner is " + r7, Toast.LENGTH_SHORT).show();
        }
        if (r1 == r2 && r2 == r3){
            Toast.makeText(this, "Winner is " + r1, Toast.LENGTH_SHORT).show();
        }
        if (r1 == r4 && r4 == r7){
            Toast.makeText(this, "Winner is " + r1, Toast.LENGTH_SHORT).show();
        }
        if (r2 == r5 && r5 == r8){
            Toast.makeText(this, "Winner is " + r2, Toast.LENGTH_SHORT).show();
        }
        if (r3 == r6 && r6 == r9){
            Toast.makeText(this, "Winner is " + r3, Toast.LENGTH_SHORT).show();
        }
        if (r1 == r5 && r5 == r9){
            Toast.makeText(this, "Winner is " + r1, Toast.LENGTH_SHORT).show();
        }
        if (r3 == r5 && r5 == r7){
            Toast.makeText(this, "Winner is " + r3, Toast.LENGTH_SHORT).show();
        }

    }
    public void contact(View v){
        Intent i = new Intent(getApplicationContext(), Main3Activity.class);
        startActivity(i);
    }

}
