package com.razmgir.rahim.thirdac;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Main2Activity extends AppCompatActivity {

//    TextView num1, num2;
    Random rand;
    ImageView dice1, dice2, img;
    TextView total, count;
    Switch bonus;
    Button btn, restart;
    int score, counter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
//        num1 = findViewById(R.id.text1);
//        num2 = findViewById(R.id.text2);
        dice1 = findViewById(R.id.img1);
        dice2 = findViewById(R.id.img2);
        total = findViewById(R.id.textView);
        count = findViewById(R.id.textView6);
        bonus = findViewById(R.id.switch1);
        btn = findViewById(R.id.button2);
        restart = findViewById(R.id.button3);
        img = findViewById(R.id.imageView4);
    }

    public void roll(View v){
        rand = new Random();
        int rand1 = rand.nextInt(6) + 1;
        int rand2 = (int)(Math.random()*6)+1;
//        num1.setText(Integer.toString(rand1));
//        num2.setText(Integer.toString(rand2));

        String dName = "d" + rand1; //the clever line
        int id = getResources().getIdentifier(dName , "drawable", getPackageName());
        dice1.setImageResource(id);

//        if (rand1 == 1){
//            dice1.setImageResource(R.drawable.d1);
//        }
//        if (rand1 == 2){
//            dice1.setImageResource(R.drawable.d2);
//        }
//        if (rand1 == 3){
//            dice1.setImageResource(R.drawable.d3);
//        }
//        if (rand1 == 4){
//            dice1.setImageResource(R.drawable.d4);
//        }
//        if (rand1 == 5){
//            dice1.setImageResource(R.drawable.d5);
//        }
//        if (rand1 == 6){
//            dice1.setImageResource(R.drawable.d6);
//        }

        switch (rand2) {
            case 1:
                dice2.setImageResource(R.drawable.d1);
                break;
            case 2:
                dice2.setImageResource(R.drawable.d2);
                break;
            case 3:
                dice2.setImageResource(R.drawable.d3);
                break;
            case 4:
                dice2.setImageResource(R.drawable.d4);
                break;
            case 5:
                dice2.setImageResource(R.drawable.d5);
                break;
            case 6:
                dice2.setImageResource(R.drawable.d6);
                break;
            default:
                dice2.setImageResource(R.drawable.d1);
        }
        counter ++;
        count.setText("Count: " + counter);
        if((bonus.isChecked())&&(rand1 == rand2)) {
            score += (rand1 + rand2)*2;
            Toast.makeText(this, "Bonus!", Toast.LENGTH_SHORT).show();
        }
        else {
            score += rand1 + rand2;
        }
        total.setText("Total Score: " + score);
        // check the end of the game
        if (counter >= 10){
            dice1.setVisibility(View.INVISIBLE);
            dice2.setVisibility(View.INVISIBLE);
            count.setVisibility(View.INVISIBLE);
            btn.setVisibility(View.INVISIBLE);
            bonus.setVisibility(View.INVISIBLE);
            restart.setVisibility(View.VISIBLE);
            img.setVisibility(View.VISIBLE);
        }

    }
//
    public void restart(View v) {
        dice1.setImageResource(R.drawable.d1);
        dice2.setImageResource(R.drawable.d1);
        bonus.setChecked(false);
        counter = 0;
        score = 0;
        count.setText("Count:");
        total.setText("Total score:");
        dice1.setVisibility(View.VISIBLE);
        dice2.setVisibility(View.VISIBLE);
        count.setVisibility(View.VISIBLE);
        btn.setVisibility(View.VISIBLE);
        bonus.setVisibility(View.VISIBLE);
        restart.setVisibility(View.INVISIBLE);
        img.setVisibility(View.INVISIBLE);
    }
}
